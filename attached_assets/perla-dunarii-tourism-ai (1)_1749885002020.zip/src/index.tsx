
import React from 'react';
import ReactDOM from 'react-dom/client';

const App = () => (
    <div>
        <h1>Welcome to Perla Dunării Tourism AI Dashboard</h1>
        <p>Secured and Powered by Blockchain</p>
    </div>
);

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<App />);
